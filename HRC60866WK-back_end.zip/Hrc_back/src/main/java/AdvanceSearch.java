import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@SuppressWarnings("serial")
@WebServlet("/AdvanceSearch")
public class AdvanceSearch extends HttpServlet {
  
  public void doGet(HttpServletRequest req, HttpServletResponse res) {
    String doc_id = req.getParameter ("doc_id");
        String cust_number = req.getParameter ("cust_number");
        String invoice_id = req.getParameter ("invoice_id");
        String buisness_year = req.getParameter ("buisness_year");
    try {
    String url = "jdbc:mysql://localhost:3306/grey_goose?zeroDateTimeBehavior=convertToNull";
    String uname = "root";
    String pass = "Aman@1234";
    res.setHeader("Access-Control-Allow-Origin", "*");
    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection conn = DriverManager.getConnection(url, uname, pass);
    
    String query = "select * from winter_internship " + "where doc_id = " + doc_id + " and cust_number = " + cust_number + " "
        + "and buisness_year = " + buisness_year + " and invoice_id = " + invoice_id;
    Statement ps = conn.createStatement();
    //ps.setString (1, doc_id);
        //ps.setString (2, cust_number);
        //ps.setString (3, invoice_id);
        //ps.setString (4, buisness_year);
    System.out.print(query);    
    ResultSet rs = ps.executeQuery(query);
    
    FetchPojo p = new FetchPojo();
    
    while(rs.next()) {
      p.setSi_no(rs.getInt("si_no"));
      p.setBusiness_code(rs.getString("business_code"));
      p.setCust_no(rs.getInt("cust_number"));
      p.setBusiness_year(rs.getInt("buisness_year"));
      p.setArea_business(rs.getString("area_business"));
      p.setCust_payment_term(rs.getString("cust_payment_terms"));
      p.setDoc_id(rs.getString("doc_id"));
      p.setDocument_type(rs.getString("document_type"));
      p.setInvoice_currency(rs.getString("invoice_currency"));
      p.setInvoice_id(rs.getInt("invoice_id"));
      p.setIsOpen(rs.getByte("isOpen"));
      p.setPosting_id(rs.getInt("posting_id"));
      p.setTotal_open_amount(rs.getDouble("total_open_amount"));
      p.setBaseline_create_date1(rs.getDate("baseline_create_date"));
      p.setPredicted(rs.getString("predicted"));
      p.setClear_date(rs.getDate("clear_date"));
      p.setDocument_create_date(rs.getDate("document_create_date"));
      p.setDue_in_date(rs.getDate("due_in_date"));
      p.setPosting_date(rs.getDate("posting_date"));
    }
    
    Gson g = new Gson();
    String jsonData = g.toJson(p);
    PrintWriter out = res.getWriter();
    
    out.print(jsonData);
    } catch (Exception e) {
      e.printStackTrace();
    }
    
  }
  
}