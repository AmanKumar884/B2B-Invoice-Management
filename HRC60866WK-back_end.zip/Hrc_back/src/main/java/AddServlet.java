import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String url ="jdbc:mysql://localhost:3306/grey_goose";
		 String user = "root";
		 String pass ="Aman@1234";
			
		 String business_code=request.getParameter("business_code");
			
		  int cust_no=Integer.parseInt(request.getParameter("cust_no"));
		 Date clear_date=Date.valueOf(request.getParameter("clear_date"));
		  int business_year=Integer.parseInt(request.getParameter("business_year"));
		  String doc_id=request.getParameter("doc_id");
		  Date posting_date=Date.valueOf(request.getParameter("posting_date"));
		  Date document_create_date=Date.valueOf(request.getParameter("document_create_date"));
		 
		  Date due_in_date=Date.valueOf(request.getParameter("due_in_date"));
		  String invoice_currency=request.getParameter("invoice_currency");
		  String document_type=request.getParameter("document_type");
		  int posting_id=Integer.parseInt(request.getParameter("posting_id"));
		 
		  double total_open_amount=Double.parseDouble(request.getParameter("total_amount_amount"));
		  Date baseline_create_date1=Date.valueOf(request.getParameter("baseline_create_date"));;
		  String cust_payment_term=request.getParameter("cust_payment_term");
		  int invoice_id=Integer.parseInt(request.getParameter("invoice_id"));
		  
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn =DriverManager.getConnection(url,user,pass);
			PreparedStatement pst = conn.prepareStatement("insert into winter_internship values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
			pst.setString(1, business_code);
			pst.setInt(2, cust_no);
			pst.setDate(3, (java.sql.Date) clear_date);
			pst.setInt(4, business_year);
			pst.setString(5, doc_id);
			pst.setDate(6, (java.sql.Date) posting_date);
			pst.setDate(7, (java.sql.Date) document_create_date);
			pst.setDate(8, (java.sql.Date) due_in_date);
			pst.setString(9, invoice_currency);
			pst.setString(10, document_type);
			pst.setInt(11, posting_id);
			pst.setDouble(12,total_open_amount);
			pst.setDate(13, (java.sql.Date)baseline_create_date1);
			pst.setString(14, cust_payment_term);
			pst.setInt(15, invoice_id);
			
			
			pst.executeUpdate();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}