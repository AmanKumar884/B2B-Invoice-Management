import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditServlet
 */
@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String url ="jdbc:mysql://localhost:3306/grey_goose";
		 String user = "root";
		 String pass ="Aman@1234";
		 response.setHeader("Access-Control-Allow-Origin", "*");
		 int s_no=Integer.parseInt(request.getParameter("si_no"));
		 String invoice=request.getParameter("invoice_currency");
		 String c_p_t=request.getParameter("cust_pay_term");
		 System.out.println(s_no);
		 try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn =DriverManager.getConnection(url,user,pass);
				PreparedStatement pst = conn.prepareStatement("update winter_internship set invoice_currency=?, cust_payment_terms=? where sl_no=?");
				
				pst.setString(1, invoice);
				pst.setString(2, c_p_t);
				pst.setInt(3, s_no);
				pst.executeUpdate();
				
		
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}