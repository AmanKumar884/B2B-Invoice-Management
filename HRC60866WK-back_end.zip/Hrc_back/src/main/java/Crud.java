//import java.sql.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;


public class Crud {

	
	
	
		public ArrayList<FetchPojo> getData()
		{
			ArrayList<FetchPojo> ALLStudents =new ArrayList<>();
			 
			 int si_no;
			String business_code;
			
			  int cust_no;
			 			  Date clear_date;
			  int business_year;
			  String doc_id;
			  Date posting_date;
			  Date document_create_date;
			  Date document_create_date1;
			  Date due_in_date;
			  String invoice_currency;
			  String document_type;
			  int posting_id;
			  String area_business;
			  double total_open_amount;
			  Date baseline_create_date1;
			  String cust_payment_term;
			  int invoice_id;
			  byte isOpen;
			  String predicted;
			try {

				 Connection conn =null;
				 String url ="jdbc:mysql://localhost:3306/grey_goose";
				 String user = "root";
				 String pass ="Aman@1234";
					
					
						try {
							Class.forName("com.mysql.jdbc.Driver");
							conn =DriverManager.getConnection(url,user,pass);
							
							 String sql_query="SELECT * ,if(clear_date = '0000-00-00', null, clear_date) as clear_date1 from winter_internship";
							 //,if(clear_date = '0000-00-00', null, clear_date) as clear_date1 
							 PreparedStatement pst = conn.prepareStatement(sql_query);
						
							 
							 ResultSet rs = pst.executeQuery();
							
							 while(rs.next())
							 {
									FetchPojo s = new FetchPojo();
								 	si_no = rs.getInt("sl_no");
								 	 business_code=rs.getString("business_code");
								 	 cust_no=rs.getInt("cust_number");
								 	clear_date=rs.getDate("clear_date1");
								 	 business_year=rs.getInt("buisness_year");
								 	 
								 	 doc_id=rs.getString("doc_id");
								 	 posting_date=rs.getDate("posting_date");
								 	document_create_date=rs.getDate("document_create_date");
								 	document_create_date1=rs.getDate("document_create_date1");
								 			due_in_date=rs.getDate("due_in_date");
								 	invoice_currency=rs.getString("invoice_currency");
								 	document_type=rs.getString("document_type");
								 	posting_id=rs.getInt("posting_id");
								 	area_business=rs.getString("area_business");
								 	total_open_amount=rs.getInt("total_open_amount");
								 	baseline_create_date1=rs.getDate("baseline_create_date");
								 	cust_payment_term=rs.getString("cust_payment_terms");
								 	invoice_id=rs.getInt("invoice_id");
								 	isOpen=rs.getByte("isOpen");
								 	predicted=rs.getString("aging_bucket");
								 	
								 	
								 	
								s.setSi_no(si_no);	
								s.setArea_business(area_business);
								s.setBaseline_create_date1(baseline_create_date1);
								s.setBusiness_code(business_code);
							
								s.setBusiness_year(business_year);
								s.setClear_date(clear_date);
								
								s.setCust_no(cust_no);
								s.setCust_payment_term(cust_payment_term);
								s.setDoc_id(doc_id);
								s.setDocument_create_date(document_create_date);
								s.setDocument_create_date1(document_create_date1);
								s.setDocument_type(document_type);
								s.setDue_in_date(due_in_date);
								s.setInvoice_currency(invoice_currency);
								s.setInvoice_id(invoice_id);
								s.setIsOpen(isOpen);
								s.setPosting_date(posting_date);
								s.setPosting_id(posting_id);
								s.setPredicted(predicted);
								s.setSi_no(si_no);
								
							s.setTotal_open_amount(total_open_amount);
								
									
									ALLStudents.add(s);
									
									
									
							 }
						} catch (ClassNotFoundException e) {
							
							e.printStackTrace();
						} catch (SQLException e) {
							e.printStackTrace();
						}
						
			 
			 
			
			}
			catch (Exception e) {
				e.printStackTrace();
				
			}
			
			return ALLStudents;
			
		
		}
		
		
		
}